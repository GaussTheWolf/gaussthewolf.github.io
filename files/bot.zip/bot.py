# from nltk.tokenize import RegexpTokenizer
import re
import random
import markov
from key import keys
import time
import tweepy

SCREEN_NAME = keys['screen_name']
CONSUMER_KEY = keys['consumer_key']
CONSUMER_SECRET = keys['consumer_secret']
ACCESS_TOKEN = keys['access_token']
ACCESS_TOKEN_SECRET = keys['access_token_secret']

auth = tweepy.OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
auth.set_access_token(ACCESS_TOKEN, ACCESS_TOKEN_SECRET)

api = tweepy.API(auth)

try:
    api.verify_credentials()
    print("Authentication OK")
except:
    print("Error during authentication")
    exit()

# Create new Markov class
markovObj = markov.Markov(dictFile='glitch.dict', maxWordInSentence= 100)

while True:

    twitterText = []

    for _ in range(10):
        text = markovObj.genText()
        #print(text)
        if len(text) <= 280 and text.endswith('.'):
            twitterText.append(text)

    print("\n\n")
    #pprint.pprint(twitterText)

    if(len(twitterText) > 0):
        maxid = 0
        for i in range(1, len(twitterText)):
            if(len(twitterText[i]) > len(twitterText[maxid])):
                maxid = i

        print(twitterText[maxid])
        api.update_status(status=twitterText[maxid])
        time.sleep(600)
